<div class="col-md-8"><!--Start 1st column-->
					<form action="" method="POST">
						<input type="text" class="form-control" name="name" placeholder="Name">
						<br>
						<input type="text" class="form-control" name="subject" placeholder="Subject">
						<br>
						<input type="email" class="form-control" name="email" placeholder="Email">
						<br>
						<textarea class="form-control" name="message" placeholder="How can we help you?" style="height:150px"></textarea><br>
						<br>
						<input type="submit" class="btn btn-primary" value="Send" name="submit">
						<br><br>
					</form>
				</div><!--End 1st column-->